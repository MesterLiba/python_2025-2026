import metodusok as m

#m.feladat_1()
#m.feladat_1full()
#m.feladat_3()
m.feladat_4()